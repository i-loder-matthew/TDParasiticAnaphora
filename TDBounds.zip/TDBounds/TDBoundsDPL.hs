{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE BlockArguments #-}
{-# OPTIONS_GHC -Wno-unrecognised-pragmas #-}
{-# HLINT ignore "Use :" #-}



import Prelude hiding ((*), (!))
import LambdaCalc
import TDBoundsPretty ( showParse, showParse', prettyProof , outTrees', withDens, withoutDens)
import TDBoundsCFG
import Data.Maybe ( fromMaybe )


demoLex :: Lexicon
demoLex = map mkLex
  [ ("x"            , [( Nothing, Var  , effR (Tpl G I) (effW T E)               )] ++
                      [( Nothing, Var  , V                                       )])
  , ("lower"        , [( Nothing, Op   , effR (Tpl G I) (effW T (effR I T)) :->
                                         effR (Tpl G I) (effW T T)               )])
  , ("left"         , [( Nothing, Pred1, effR I (E :-> T)                        )])
  , ("bathroom"     , [( Nothing, Pred1, effR I (E :-> T)                        )])
  , ("bathroom2"    , [( Nothing, Pred1, E :-> T                                 )])
  , ("groundfloor"  , [( Nothing, Pred1, effR I (E :-> T)                        )])
  , ("not"          , [( Nothing, Conn1, T :-> T                                 )])
  , ("and"          , [( Nothing, Conn2, T :-> T :-> T                           )])
  , ("and2"         , [( Nothing, Conn2, effR (Tpl G I) (effW T T) :-> 
                                         effR (Tpl G I) (effW T T) :-> 
                                         effR (Tpl G I) (effW T T)               )])
  , ("bexists"      , [( Nothing, Q    , V :-> effR (Tpl G I) (effW T T) :->
                                         effR (Tpl G I) (effW T T)               )])
  , ("pfoc"         , [( Nothing, Op   , effR I (E :-> T) :->
                                         effC (effR (Tpl G I) (effW T T)) 
                                         (effR (Tpl G I) (effW T T)) 
                                         (effR I (E :-> T))                      )])

  ]
  where
    first  (a,s,t) f = (f a, s, t)
    second (s , a) f = (s , f s a)
    mkLex w = second w $ \s -> map (`first` fromMaybe (make_con s))
  --   idTerm = let a = make_var "a" in a ! a
  --   pushTerm = let x = make_var "x" in x ! (x * x)

  --   ann = make_con "a"
  --   mary = make_con "m"
  --   x2 = let g = make_var "g" in g ! (g % make_con "x") % make_con "$\\neq$" % make_con "\\#" * (g % make_con "x")
  --   left = let w = make_var "w" in w ! (make_con "left" % w)
  --   bexists =
  --       let v = make_var "v" in
  --       let p = make_var "p" in
  --       let a = make_var "a" in
  --       let g = make_var "g" in
  --           v ! p ! g !
  --               ( ((make_con "$\\exists$" % a) % _2 (p % (g % make_con "[" % v % make_con "$\\rightarrow$" % a % make_con "]")) ) % make_con "$\\Rightarrow$" % _2 (p % g)) *
  --               ((make_con "$\\exists$" % a )% _2 (p % (g % make_con "[" % v % make_con "$\\rightarrow$" % a % make_con "]")))

-- a toy Context-Free Grammar
demoCFG :: CFG
demoCFG = curry \case
  (Pred1, Var  ) -> [Prop]
  (Conn1, Prop ) -> [Prop]
  (Prop , Conn2) -> [Conn1]
  (Q    , Var  ) -> [Conn1]
  (Op   , Prop ) -> [Prop]
  (Op   , Pred1) -> [Pred1]
  (_    , _    ) -> []






{- Test cases -}

s1 = "left x"
t1 = effR (Tpl G I) (effW T (effR I T))
t1alt = effR (Tpl G I) (effW T T)

s2 = "bexists x"
t2 = effR (Tpl G I) (effW T T) :-> effR (Tpl G I) (effW T T)

s3 = "lower left x"
t3 = effR (Tpl G I) (effW T T)

s4 = "bexists x lower left x"
t4 = effR (Tpl G I) (effW T T)

s5 = "pfoc left"
t5 = effC (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T T)) (effR I (E :-> T))
t5alt = effC (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T T)) (E :-> T)

s6 = "pfoc left x"
t6 = effC (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T (effR I T)))
t6alt = effC (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T T))


s7 = "lower pfoc left x"
t7 = effC (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T T))
t7alt = effR (Tpl G I) (effW T T)

s8 = "bexists x lower pfoc left x"
t8 = effC (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T T))
t8alt = effR (Tpl G I) (effW T T)

s9 = "not bexists x lower pfoc left x"
t9 = effR (Tpl G I) (effW T T)
t9alt = effC (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T T)) (effR (Tpl G I) (effW T T))

s10 = "not lower bathroom x and2 bathroom x"
t10 = effR (Tpl G I) (effW T T)

{- Testing helper function -}

main :: IO ()
-- main = mapM_ putStrLn ps --  ++ qs
main = outTrees' withoutDens demoCFG demoLex (hasType t10) s10
  where
    ps = [s3] >>= fromMaybe ["No parse"] . showParse demoCFG demoLex
    -- qs = fromMaybe ["No parse"] $ showParse' demoCFG demoLex (hasType T) prettyProof s6

